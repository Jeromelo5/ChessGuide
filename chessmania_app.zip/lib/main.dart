import 'package:flutter/material.dart';
import 'screens/chess_board_screen.dart';
import 'theme/theme.dart';

void main() {
  runApp(const ChessManiaApp());
}

class ChessManiaApp extends StatelessWidget {
  const ChessManiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ChessMania',
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: ThemeMode.system,
      home: const ChessBoardScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
