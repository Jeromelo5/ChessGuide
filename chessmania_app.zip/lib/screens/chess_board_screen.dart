import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

class ChessBoardScreen extends StatefulWidget {
  const ChessBoardScreen({super.key});

  @override
  State<ChessBoardScreen> createState() => _ChessBoardScreenState();
}

class _ChessBoardScreenState extends State<ChessBoardScreen> {
  String importedPGN = '';

  void _importPGN() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pgn']);
    if (result != null && result.files.single.path != null) {
      final file = File(result.files.single.path!);
      final contents = await file.readAsString();
      setState(() {
        importedPGN = contents;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("ChessMania"),
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            onPressed: _importPGN,
            tooltip: 'Import PGN',
          ),
        ],
      ),
      body: Center(
        child: importedPGN.isEmpty
            ? const Text('No PGN imported.')
            : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Text(importedPGN),
              ),
      ),
    );
  }
}
